public class Nodo1 {
    int info;
    Nodo1 liga;

    public Nodo1(int x){
        info = x;
        liga = null;
    }

}
