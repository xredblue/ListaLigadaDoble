public class Test_ListaOrde {
    public static void main(String[] args) {
        ListaOrdenada l = new ListaOrdenada();
        l.insertar(8);
        l.insertar(7);
        l.insertar(1);
        l.insertar(10);
    }
}
