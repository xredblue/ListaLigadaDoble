public class TestPrueba {
    public static void main(String[] args) {
        ListaD l = new ListaD();
        l.insertar(2);
        l.insertar(4);
        l.insertar(6);
        l.insertar(8);
        l.recorrerDerecha();
        l.recorrerDerecha();
        l.recorrerIzquierda();
        l.recorrerIzquierda();
    }
}
