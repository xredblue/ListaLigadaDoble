public class NodoD {
    int info;
    NodoD sig;
    NodoD ant;

    public NodoD(int valor){
        info=valor;
        sig=null;
        ant=null;
    }
}
